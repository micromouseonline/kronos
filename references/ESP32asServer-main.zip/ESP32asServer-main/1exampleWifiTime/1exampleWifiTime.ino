#include <WiFi.h>
#include <time.h>

// 🔹 CHANGE THESE
const char* ssid = "Bertovic";
const char* password = "18072019";

// NTP server
const char* ntpServer = "pool.ntp.org";

// Timezone offset (seconds)
// Example: UTC +5:30 = 5.5 * 3600 = 19800
const long gmtOffset_sec = 0;        // Change for your timezone
const int daylightOffset_sec = 0;    // Change if DST applies

void setup() {
  Serial.begin(115200);

  // Connect to Wi-Fi
  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected!");

  // Initialize time
  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);

  Serial.println("Time initialized");
}

void loop() {
  struct tm timeinfo;

  if (!getLocalTime(&timeinfo)) {
    Serial.println("Failed to obtain time");
    delay(1000);
    return;
  }

  Serial.printf("Date: %04d-%02d-%02d  ",
                timeinfo.tm_year + 1900,
                timeinfo.tm_mon + 1,
                timeinfo.tm_mday);

  Serial.printf("Time: %02d:%02d:%02d\n",
                timeinfo.tm_hour,
                timeinfo.tm_min,
                timeinfo.tm_sec);

  delay(1000); // Update every second
}

